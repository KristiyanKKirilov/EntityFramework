﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-M5SEPFK\SQLEXPRESS;Database=CarDealer;Integrated Security=True;TrustServerCertificate=True;";
    }
}
