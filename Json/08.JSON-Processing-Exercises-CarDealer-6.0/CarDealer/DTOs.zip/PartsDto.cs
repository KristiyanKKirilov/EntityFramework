﻿namespace CarDealer
{
    internal class PartsDto
    {
    }
}