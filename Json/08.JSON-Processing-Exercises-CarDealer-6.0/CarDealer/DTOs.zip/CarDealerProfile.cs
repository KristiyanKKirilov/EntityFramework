﻿using AutoMapper;
using CarDealer.DTOs;
using CarDealer.Models;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            CreateMap<SupplierDto, Supplier>();
            CreateMap<PartDto, Part>();
            CreateMap<CarDto, Car>();
            CreateMap<CustomerDto, Customer>();
            CreateMap<SaleDto, Sale>();
            CreateMap<Customer, CustomerDto>();
            CreateMap<Car, CarDto>();   
        }
    }
}
