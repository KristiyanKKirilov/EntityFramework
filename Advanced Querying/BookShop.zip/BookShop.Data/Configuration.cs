﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-M5SEPFK\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
