﻿namespace Cadastre.Data.Enumerations
{
    public enum Region
    {
        SouthEast = 0, 
        SouthWest, 
        NorthEast, 
        NorthWest
    }
}
