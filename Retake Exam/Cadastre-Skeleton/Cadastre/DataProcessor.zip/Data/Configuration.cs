﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-M5SEPFK\SQLEXPRESS;Database=Cadastre;Integrated Security=True;TrustServerCertificate=True;";
    }
}
