﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-M5SEPFK\SQLEXPRESS;Database=Medicines2;Integrated Security=True;TrustServerCertificate=True;";
    }
}
