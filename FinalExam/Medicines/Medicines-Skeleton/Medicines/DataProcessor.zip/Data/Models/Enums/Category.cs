﻿namespace Medicines.Data.Models.Enums
{
    public enum Category
    {
        Analgesic = 0,
        Antibiotic, 
        Antiseptic, 
        Sedative,
        Vaccine
    }
}
